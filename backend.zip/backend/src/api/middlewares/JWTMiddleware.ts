// import * as express from 'express';
// import * as jwt from 'jwt';
// import { ExpressMiddlewareInterface, Middleware } from 'routing-controllers';
// import { env } from '../../env';

// @Middleware({ type: 'before' })
// export class JWTMiddleware implements ExpressMiddlewareInterface {
//     public use(
//         req: express.Request,
//         res: express.Response,
//         next: express.NextFunction
//     ): any {
//         return jwt()(req, res, next);
//     }
// }
