import * as nock from 'nock';
import * as request from 'supertest';

import { Task } from '../../../src/api/models/Task';
import { CreateBruce } from '../../../src/database/seeds/CreateBruce';
import { runSeed } from '../../../src/lib/seed';
import { closeDatabase } from '../../../test/utils/database';
import { BootstrapSettings } from '../../../test/e2e/utils/bootstrap';
import { prepareServer } from '../../../test/e2e/utils/server';

describe('/api/tasks', () => {

    let bruce: Task;
    let bruceAuthorization: string;
    let settings: BootstrapSettings;

    // -------------------------------------------------------------------------
    // Setup up
    // -------------------------------------------------------------------------

    beforeAll(async () => {
        settings = await prepareServer({ migrate: true });
        bruce = await runSeed<Task>(CreateBruce);
        bruceAuthorization = Buffer.from(`${bruce.firstName}:1234`).toString('base64');
    });

    // -------------------------------------------------------------------------
    // Tear down
    // -------------------------------------------------------------------------

    afterAll(async () => {
        nock.cleanAll();
        await closeDatabase(settings.connection);
    });

    // -------------------------------------------------------------------------
    // Test cases
    // -------------------------------------------------------------------------

    test('GET: / should return a list of tasks', async (done) => {
        const response = await request(settings.app)
            .get('/api/tasks')
            .set('Authorization', `Basic ${bruceAuthorization}`)
            .expect('Content-Type', /json/)
            .expect(200);

        expect(response.body.length).toBe(1);
        done();
    });

    test('GET: /:id should return bruce', async (done) => {
        const response = await request(settings.app)
            .get(`/api/tasks/${bruce.id}`)
            .set('Authorization', `Basic ${bruceAuthorization}`)
            .expect('Content-Type', /json/)
            .expect(200);

        expect(response.body.id).toBe(bruce.id);
        expect(response.body.firstName).toBe(bruce.firstName);
        expect(response.body.lastName).toBe(bruce.lastName);
        expect(response.body.email).toBe(bruce.email);
        done();
    });

});
