declare module '*.json' {
    let json: any;
    export default json;
}
