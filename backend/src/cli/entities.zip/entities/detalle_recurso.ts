import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {usuarios} from "./usuarios";


@Entity("detalle_recurso",{schema:"public"})
export class detalle_recurso {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("integer",{ 
        nullable:false,
        name:"recursoyservicios_id"
        })
    recursoyservicios_id:number;
        

    @Column("integer",{ 
        nullable:false,
        name:"transacciones_id"
        })
    transacciones_id:number;
        

    @Column("integer",{ 
        nullable:true,
        name:"id_usuarios"
        })
    id_usuarios:number | null;
        

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss2:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss3:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss4:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss5:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss6:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss7:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss8:usuarios[];
    

   
    @OneToMany(type=>usuarios, usuarios=>usuarios.id_detalle_recurso,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    usuarioss9:usuarios[];
    
}
