import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";


@Entity("many_recurso_calendario_has_many_usuarios",{schema:"public"})
export class many_recurso_calendario_has_many_usuarios {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_recurso_calendario"
        })
    id_recurso_calendario:number;
        

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_usuarios"
        })
    id_usuarios:number;
        
}
