import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";


@Entity("many_correos_has_many_detalle_recurso",{schema:"public"})
export class many_correos_has_many_detalle_recurso {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_correos"
        })
    id_correos:number;
        

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_detalle_recurso"
        })
    id_detalle_recurso:number;
        
}
