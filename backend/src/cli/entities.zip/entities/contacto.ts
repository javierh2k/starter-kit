import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_contacto_has_many_proveedor_servicios} from "./many_contacto_has_many_proveedor_servicios";


@Entity("contacto",{schema:"public"})
export class contacto {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"proveedor_servicios_id"
        })
    proveedor_servicios_id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"telefono"
        })
    telefono:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"direccion"
        })
    direccion:string | null;
        

   
    @OneToOne(type=>many_contacto_has_many_proveedor_servicios, many_contacto_has_many_proveedor_servicios=>many_contacto_has_many_proveedor_servicios.id_contacto,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_contacto_has_many_proveedor_servicios:many_contacto_has_many_proveedor_servicios | null;


   
    @OneToOne(type=>many_contacto_has_many_proveedor_servicios, many_contacto_has_many_proveedor_servicios=>many_contacto_has_many_proveedor_servicios.id_contacto,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_contacto_has_many_proveedor_servicios2:many_contacto_has_many_proveedor_servicios | null;


   
    @OneToOne(type=>many_contacto_has_many_proveedor_servicios, many_contacto_has_many_proveedor_servicios=>many_contacto_has_many_proveedor_servicios.id_contacto,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_contacto_has_many_proveedor_servicios3:many_contacto_has_many_proveedor_servicios | null;


   
    @OneToOne(type=>many_contacto_has_many_proveedor_servicios, many_contacto_has_many_proveedor_servicios=>many_contacto_has_many_proveedor_servicios.id_contacto,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_contacto_has_many_proveedor_servicios4:many_contacto_has_many_proveedor_servicios | null;

}
