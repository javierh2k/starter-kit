import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {proveedor_servicios} from "./proveedor_servicios";


@Entity("many_proveedor_servicios_has_many_zona",{schema:"public"})
export class many_proveedor_servicios_has_many_zona {

   
    @OneToOne(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.many_proveedor_servicios_has_many_zona,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_proveedor_servicios'})
    id_proveedor_servicios:proveedor_servicios | null;

    @OneToOne(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.many_proveedor_servicios_has_many_zona2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_proveedor_servicios'})
    id_proveedor_servicios:proveedor_servicios | null;

    @OneToOne(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.many_proveedor_servicios_has_many_zona3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_proveedor_servicios'})
    id_proveedor_servicios:proveedor_servicios | null;

    @OneToOne(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.many_proveedor_servicios_has_many_zona4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_proveedor_servicios'})
    id_proveedor_servicios:proveedor_servicios | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_zona"
        })
    id_zona:number;
        
}
