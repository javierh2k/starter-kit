import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";


@Entity("many_detalle_recurso_has_many_recursoyservicios",{schema:"public"})
export class many_detalle_recurso_has_many_recursoyservicios {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_detalle_recurso"
        })
    id_detalle_recurso:number;
        

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_recursoyservicios"
        })
    id_recursoyservicios:number;
        

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"conjuntos_id_recursoyservicios"
        })
    conjuntos_id_recursoyservicios:number;
        
}
