import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_ticket_bitacora_has_many_pqrsf} from "./many_ticket_bitacora_has_many_pqrsf";


@Entity("ticket_bitacora",{schema:"public"})
export class ticket_bitacora {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"fecha"
        })
    fecha:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"texto"
        })
    texto:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"pqrsf_id"
        })
    pqrsf_id:number;
        

   
    @OneToOne(type=>many_ticket_bitacora_has_many_pqrsf, many_ticket_bitacora_has_many_pqrsf=>many_ticket_bitacora_has_many_pqrsf.id_ticket_bitacora,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_ticket_bitacora_has_many_pqrsf:many_ticket_bitacora_has_many_pqrsf | null;


   
    @OneToOne(type=>many_ticket_bitacora_has_many_pqrsf, many_ticket_bitacora_has_many_pqrsf=>many_ticket_bitacora_has_many_pqrsf.id_ticket_bitacora,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_ticket_bitacora_has_many_pqrsf2:many_ticket_bitacora_has_many_pqrsf | null;


   
    @OneToOne(type=>many_ticket_bitacora_has_many_pqrsf, many_ticket_bitacora_has_many_pqrsf=>many_ticket_bitacora_has_many_pqrsf.id_ticket_bitacora,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_ticket_bitacora_has_many_pqrsf3:many_ticket_bitacora_has_many_pqrsf | null;


   
    @OneToOne(type=>many_ticket_bitacora_has_many_pqrsf, many_ticket_bitacora_has_many_pqrsf=>many_ticket_bitacora_has_many_pqrsf.id_ticket_bitacora,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_ticket_bitacora_has_many_pqrsf4:many_ticket_bitacora_has_many_pqrsf | null;

}
