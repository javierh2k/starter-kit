import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {tipo_transaccion} from "./tipo_transaccion";
import {many_conjuntos_has_many_zona} from "./many_conjuntos_has_many_zona";


@Entity("conjuntos",{schema:"public"})
export class conjuntos {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"codigo"
        })
    codigo:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"ciudad"
        })
    ciudad:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"direccion"
        })
    direccion:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"telefono"
        })
    telefono:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"correo"
        })
    correo:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"zona_id"
        })
    zona_id:number;
        

   
    @ManyToOne(type=>tipo_transaccion, tipo_transaccion=>tipo_transaccion.conjuntoss,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_tipo_transaccion'})
    id_tipo_transaccion:tipo_transaccion | null;

    @ManyToOne(type=>tipo_transaccion, tipo_transaccion=>tipo_transaccion.conjuntoss2,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_tipo_transaccion'})
    id_tipo_transaccion:tipo_transaccion | null;

    @ManyToOne(type=>tipo_transaccion, tipo_transaccion=>tipo_transaccion.conjuntoss3,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_tipo_transaccion'})
    id_tipo_transaccion:tipo_transaccion | null;

    @ManyToOne(type=>tipo_transaccion, tipo_transaccion=>tipo_transaccion.conjuntoss4,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_tipo_transaccion'})
    id_tipo_transaccion:tipo_transaccion | null;


   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_conjuntos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona:many_conjuntos_has_many_zona | null;


   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_conjuntos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona2:many_conjuntos_has_many_zona | null;


   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_conjuntos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona3:many_conjuntos_has_many_zona | null;


   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_conjuntos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona4:many_conjuntos_has_many_zona | null;

}
