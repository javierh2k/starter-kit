import {
    Column, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne,
    PrimaryColumn, PrimaryGeneratedColumn, RelationId
} from 'typeorm';

import { categoria } from './categoria';

@Entity("ManyInmuebleHasManyCategoria",{schema:"public"})
export class ManyInmuebleHasManyCategoria {

    @Column("integer",{
        nullable:false,
        primary:true,
        name:"id_inmueble"
        })
    id_inmueble:number;



    @OneToOne(type=>categoria, categoria=>categoria.ManyInmuebleHasManyCategoria,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_categoria'})
    id_categoria:categoria | null;

}
