import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {proveedor_servicios} from "./proveedor_servicios";


@Entity("recurso_calendario",{schema:"public"})
export class recurso_calendario {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"fecha_inicial"
        })
    fecha_inicial:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"fecha_final"
        })
    fecha_final:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"recurso_id"
        })
    recurso_id:number;
        

    @Column("integer",{ 
        nullable:false,
        name:"usuarios_id"
        })
    usuarios_id:number;
        

   
    @OneToMany(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.id_recurso_calendario,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    proveedor_servicioss:proveedor_servicios[];
    

   
    @OneToMany(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.id_recurso_calendario,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    proveedor_servicioss2:proveedor_servicios[];
    

   
    @OneToMany(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.id_recurso_calendario,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    proveedor_servicioss3:proveedor_servicios[];
    

   
    @OneToMany(type=>proveedor_servicios, proveedor_servicios=>proveedor_servicios.id_recurso_calendario,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    proveedor_servicioss4:proveedor_servicios[];
    
}
