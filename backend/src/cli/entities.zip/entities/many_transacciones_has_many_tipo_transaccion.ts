import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {transacciones} from "./transacciones";


@Entity("many_transacciones_has_many_tipo_transaccion",{schema:"public"})
export class many_transacciones_has_many_tipo_transaccion {

   
    @OneToOne(type=>transacciones, transacciones=>transacciones.many_transacciones_has_many_tipo_transaccion,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_transacciones'})
    id_transacciones:transacciones | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_tipo_transaccion"
        })
    id_tipo_transaccion:number;
        
}
