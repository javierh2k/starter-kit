import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {recursoyservicios} from "./recursoyservicios";


@Entity("many_recursoyservicios_has_many_conjuntos",{schema:"public"})
export class many_recursoyservicios_has_many_conjuntos {

   
    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos7,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos8,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos9,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto5,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto6,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recursoyservicios'})
    id_recursoyservicios:recursoyservicios | null;


   
    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos5,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjuntos6,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto7,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto8,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;

    @OneToOne(type=>recursoyservicios, recursoyservicios=>recursoyservicios.many_recursoyservicios_has_many_conjunto9,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'conjuntos_id_recursoyservicios'})
    conjuntos_id_recursoyservicios:recursoyservicios | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_conjuntos"
        })
    id_conjuntos:number;
        
}
