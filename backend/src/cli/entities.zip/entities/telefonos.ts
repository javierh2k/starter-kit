import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_telefonos_has_many_usuarios} from "./many_telefonos_has_many_usuarios";


@Entity("telefonos",{schema:"public"})
export class telefonos {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"tipo"
        })
    tipo:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"numero"
        })
    numero:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"usuarios_id"
        })
    usuarios_id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"usuarios_roles_id"
        })
    usuarios_roles_id:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"contacto_id"
        })
    contacto_id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"estado"
        })
    estado:string | null;
        

   
    @OneToOne(type=>many_telefonos_has_many_usuarios, many_telefonos_has_many_usuarios=>many_telefonos_has_many_usuarios.id_telefonos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_telefonos_has_many_usuarios:many_telefonos_has_many_usuarios | null;


   
    @OneToOne(type=>many_telefonos_has_many_usuarios, many_telefonos_has_many_usuarios=>many_telefonos_has_many_usuarios.id_telefonos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_telefonos_has_many_usuarios2:many_telefonos_has_many_usuarios | null;


   
    @OneToOne(type=>many_telefonos_has_many_usuarios, many_telefonos_has_many_usuarios=>many_telefonos_has_many_usuarios.id_telefonos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_telefonos_has_many_usuarios3:many_telefonos_has_many_usuarios | null;


   
    @OneToOne(type=>many_telefonos_has_many_usuarios, many_telefonos_has_many_usuarios=>many_telefonos_has_many_usuarios.id_telefonos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_telefonos_has_many_usuarios4:many_telefonos_has_many_usuarios | null;

}
