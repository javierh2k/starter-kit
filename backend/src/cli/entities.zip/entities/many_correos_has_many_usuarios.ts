import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {correos} from "./correos";


@Entity("many_correos_has_many_usuarios",{schema:"public"})
export class many_correos_has_many_usuarios {

   
    @OneToOne(type=>correos, correos=>correos.many_correos_has_many_usuarios,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_correos'})
    id_correos:correos | null;

    @OneToOne(type=>correos, correos=>correos.many_correos_has_many_usuarios2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_correos'})
    id_correos:correos | null;

    @OneToOne(type=>correos, correos=>correos.many_correos_has_many_usuarios3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_correos'})
    id_correos:correos | null;

    @OneToOne(type=>correos, correos=>correos.many_correos_has_many_usuarios4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_correos'})
    id_correos:correos | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_usuarios"
        })
    id_usuarios:number;
        
}
