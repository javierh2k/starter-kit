import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {pqrsf} from "./pqrsf";


@Entity("many_pqrsf_has_many_usuarios",{schema:"public"})
export class many_pqrsf_has_many_usuarios {

   
    @OneToOne(type=>pqrsf, pqrsf=>pqrsf.many_pqrsf_has_many_usuarios,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_pqrsf'})
    id_pqrsf:pqrsf | null;

    @OneToOne(type=>pqrsf, pqrsf=>pqrsf.many_pqrsf_has_many_usuarios2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_pqrsf'})
    id_pqrsf:pqrsf | null;

    @OneToOne(type=>pqrsf, pqrsf=>pqrsf.many_pqrsf_has_many_usuarios3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_pqrsf'})
    id_pqrsf:pqrsf | null;

    @OneToOne(type=>pqrsf, pqrsf=>pqrsf.many_pqrsf_has_many_usuarios4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_pqrsf'})
    id_pqrsf:pqrsf | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_usuarios"
        })
    id_usuarios:number;
        
}
