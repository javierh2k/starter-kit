import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {visitantes} from "./visitantes";
import {inmueble} from "./inmueble";


@Entity("many_visitantes_has_many_inmueble",{schema:"public"})
export class many_visitantes_has_many_inmueble {

   
    @OneToOne(type=>visitantes, visitantes=>visitantes.many_visitantes_has_many_inmueble,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_visitantes'})
    id_visitantes:visitantes | null;


   
    @OneToOne(type=>inmueble, inmueble=>inmueble.many_visitantes_has_many_inmueble,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_inmueble'})
    id_inmueble:inmueble | null;

    @OneToOne(type=>inmueble, inmueble=>inmueble.many_visitantes_has_many_inmueble2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_inmueble'})
    id_inmueble:inmueble | null;

    @OneToOne(type=>inmueble, inmueble=>inmueble.many_visitantes_has_many_inmueble3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_inmueble'})
    id_inmueble:inmueble | null;

    @OneToOne(type=>inmueble, inmueble=>inmueble.many_visitantes_has_many_inmueble4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_inmueble'})
    id_inmueble:inmueble | null;

}
