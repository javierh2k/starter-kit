import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_conjuntos_has_many_zona} from "./many_conjuntos_has_many_zona";


@Entity("zona",{schema:"public"})
export class zona {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_zona,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona:many_conjuntos_has_many_zona | null;


   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_zona,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona2:many_conjuntos_has_many_zona | null;


   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_zona,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona3:many_conjuntos_has_many_zona | null;


   
    @OneToOne(type=>many_conjuntos_has_many_zona, many_conjuntos_has_many_zona=>many_conjuntos_has_many_zona.id_zona,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_conjuntos_has_many_zona4:many_conjuntos_has_many_zona | null;

}
