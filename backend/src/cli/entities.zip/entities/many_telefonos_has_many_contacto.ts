import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";


@Entity("many_telefonos_has_many_contacto",{schema:"public"})
export class many_telefonos_has_many_contacto {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_telefonos"
        })
    id_telefonos:number;
        

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_contacto"
        })
    id_contacto:number;
        
}
