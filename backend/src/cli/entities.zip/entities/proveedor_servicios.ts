import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {recurso_calendario} from "./recurso_calendario";
import {many_proveedor_servicios_has_many_zona} from "./many_proveedor_servicios_has_many_zona";


@Entity("proveedor_servicios",{schema:"public"})
export class proveedor_servicios {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nit"
        })
    nit:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"zona_id"
        })
    zona_id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"correo"
        })
    correo:string | null;
        

   
    @ManyToOne(type=>recurso_calendario, recurso_calendario=>recurso_calendario.proveedor_servicioss,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recurso_calendario'})
    id_recurso_calendario:recurso_calendario | null;

    @ManyToOne(type=>recurso_calendario, recurso_calendario=>recurso_calendario.proveedor_servicioss2,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recurso_calendario'})
    id_recurso_calendario:recurso_calendario | null;

    @ManyToOne(type=>recurso_calendario, recurso_calendario=>recurso_calendario.proveedor_servicioss3,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recurso_calendario'})
    id_recurso_calendario:recurso_calendario | null;

    @ManyToOne(type=>recurso_calendario, recurso_calendario=>recurso_calendario.proveedor_servicioss4,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_recurso_calendario'})
    id_recurso_calendario:recurso_calendario | null;


   
    @OneToOne(type=>many_proveedor_servicios_has_many_zona, many_proveedor_servicios_has_many_zona=>many_proveedor_servicios_has_many_zona.id_proveedor_servicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_proveedor_servicios_has_many_zona:many_proveedor_servicios_has_many_zona | null;


   
    @OneToOne(type=>many_proveedor_servicios_has_many_zona, many_proveedor_servicios_has_many_zona=>many_proveedor_servicios_has_many_zona.id_proveedor_servicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_proveedor_servicios_has_many_zona2:many_proveedor_servicios_has_many_zona | null;


   
    @OneToOne(type=>many_proveedor_servicios_has_many_zona, many_proveedor_servicios_has_many_zona=>many_proveedor_servicios_has_many_zona.id_proveedor_servicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_proveedor_servicios_has_many_zona3:many_proveedor_servicios_has_many_zona | null;


   
    @OneToOne(type=>many_proveedor_servicios_has_many_zona, many_proveedor_servicios_has_many_zona=>many_proveedor_servicios_has_many_zona.id_proveedor_servicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_proveedor_servicios_has_many_zona4:many_proveedor_servicios_has_many_zona | null;

}
