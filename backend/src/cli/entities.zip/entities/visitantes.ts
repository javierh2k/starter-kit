import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_visitantes_has_many_inmueble} from "./many_visitantes_has_many_inmueble";


@Entity("visitantes",{schema:"public"})
export class visitantes {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"apellido"
        })
    apellido:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"cedula"
        })
    cedula:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"inmueble_id"
        })
    inmueble_id:number;
        

   
    @OneToOne(type=>many_visitantes_has_many_inmueble, many_visitantes_has_many_inmueble=>many_visitantes_has_many_inmueble.id_visitantes,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_visitantes_has_many_inmueble:many_visitantes_has_many_inmueble | null;

}
