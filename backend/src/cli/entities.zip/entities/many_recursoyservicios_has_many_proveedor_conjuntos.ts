import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {proveedor_conjuntos} from "./proveedor_conjuntos";


@Entity("many_recursoyservicios_has_many_proveedor_conjuntos",{schema:"public"})
export class many_recursoyservicios_has_many_proveedor_conjuntos {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_recursoyservicios"
        })
    id_recursoyservicios:number;
        

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"conjuntos_id_recursoyservicios"
        })
    conjuntos_id_recursoyservicios:number;
        

   
    @OneToOne(type=>proveedor_conjuntos, proveedor_conjuntos=>proveedor_conjuntos.many_recursoyservicios_has_many_proveedor_conjuntos,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_proveedor_conjuntos'})
    id_proveedor_conjuntos:proveedor_conjuntos | null;

}
