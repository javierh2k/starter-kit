import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";


@Entity("publicidad",{schema:"public"})
export class publicidad {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"estado"
        })
    estado:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"fecha_inicial"
        })
    fecha_inicial:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"fecha_final"
        })
    fecha_final:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        name:"texto_html"
        })
    texto_html:string | null;
        
}
