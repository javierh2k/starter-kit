import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_visitantes_has_many_inmueble} from "./many_visitantes_has_many_inmueble";


@Entity("inmueble",{schema:"public"})
export class inmueble {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"ubicacion"
        })
    ubicacion:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"conjuntos_id"
        })
    conjuntos_id:number;
        

    @Column("integer",{ 
        nullable:true,
        name:"piso"
        })
    piso:number | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"bloque"
        })
    bloque:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"interior"
        })
    interior:string | null;
        

    @Column("integer",{ 
        nullable:true,
        name:"numero"
        })
    numero:number | null;
        

    @Column("integer",{ 
        nullable:true,
        name:"parqueadero"
        })
    parqueadero:number | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"categoria_id"
        })
    categoria_id:number;
        

   
    @OneToOne(type=>many_visitantes_has_many_inmueble, many_visitantes_has_many_inmueble=>many_visitantes_has_many_inmueble.id_inmueble,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_visitantes_has_many_inmueble:many_visitantes_has_many_inmueble | null;


   
    @OneToOne(type=>many_visitantes_has_many_inmueble, many_visitantes_has_many_inmueble=>many_visitantes_has_many_inmueble.id_inmueble,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_visitantes_has_many_inmueble2:many_visitantes_has_many_inmueble | null;


   
    @OneToOne(type=>many_visitantes_has_many_inmueble, many_visitantes_has_many_inmueble=>many_visitantes_has_many_inmueble.id_inmueble,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_visitantes_has_many_inmueble3:many_visitantes_has_many_inmueble | null;


   
    @OneToOne(type=>many_visitantes_has_many_inmueble, many_visitantes_has_many_inmueble=>many_visitantes_has_many_inmueble.id_inmueble,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_visitantes_has_many_inmueble4:many_visitantes_has_many_inmueble | null;

}
