import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_recursoyservicios_has_many_conjuntos} from "./many_recursoyservicios_has_many_conjuntos";


@Entity("recursoyservicios",{schema:"public"})
export class recursoyservicios {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"conjuntos_id"
        })
    conjuntos_id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"estado"
        })
    estado:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"proveedor_conjuntos_id"
        })
    proveedor_conjuntos_id:number;
        

   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos2:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos3:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos4:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos5:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos6:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos7:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos8:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjuntos9:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto2:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto3:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto4:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto5:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto6:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto7:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto8:many_recursoyservicios_has_many_conjuntos | null;


   
    @OneToOne(type=>many_recursoyservicios_has_many_conjuntos, many_recursoyservicios_has_many_conjuntos=>many_recursoyservicios_has_many_conjuntos.conjuntos_id_recursoyservicios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_conjunto9:many_recursoyservicios_has_many_conjuntos | null;

}
