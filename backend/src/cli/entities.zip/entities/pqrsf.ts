import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_pqrsf_has_many_usuarios} from "./many_pqrsf_has_many_usuarios";


@Entity("pqrsf",{schema:"public"})
export class pqrsf {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"fecha_creacion"
        })
    fecha_creacion:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"texto"
        })
    texto:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"estado"
        })
    estado:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"fecha_cierre"
        })
    fecha_cierre:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"usuarios_id"
        })
    usuarios_id:number;
        

   
    @OneToOne(type=>many_pqrsf_has_many_usuarios, many_pqrsf_has_many_usuarios=>many_pqrsf_has_many_usuarios.id_pqrsf,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_pqrsf_has_many_usuarios:many_pqrsf_has_many_usuarios | null;


   
    @OneToOne(type=>many_pqrsf_has_many_usuarios, many_pqrsf_has_many_usuarios=>many_pqrsf_has_many_usuarios.id_pqrsf,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_pqrsf_has_many_usuarios2:many_pqrsf_has_many_usuarios | null;


   
    @OneToOne(type=>many_pqrsf_has_many_usuarios, many_pqrsf_has_many_usuarios=>many_pqrsf_has_many_usuarios.id_pqrsf,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_pqrsf_has_many_usuarios3:many_pqrsf_has_many_usuarios | null;


   
    @OneToOne(type=>many_pqrsf_has_many_usuarios, many_pqrsf_has_many_usuarios=>many_pqrsf_has_many_usuarios.id_pqrsf,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_pqrsf_has_many_usuarios4:many_pqrsf_has_many_usuarios | null;

}
