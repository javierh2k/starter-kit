import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {conjuntos} from "./conjuntos";


@Entity("tipo_transaccion",{schema:"public"})
export class tipo_transaccion {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("integer",{ 
        nullable:true,
        name:"valor"
        })
    valor:number | null;
        

   
    @OneToMany(type=>conjuntos, conjuntos=>conjuntos.id_tipo_transaccion,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    conjuntoss:conjuntos[];
    

   
    @OneToMany(type=>conjuntos, conjuntos=>conjuntos.id_tipo_transaccion,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    conjuntoss2:conjuntos[];
    

   
    @OneToMany(type=>conjuntos, conjuntos=>conjuntos.id_tipo_transaccion,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    conjuntoss3:conjuntos[];
    

   
    @OneToMany(type=>conjuntos, conjuntos=>conjuntos.id_tipo_transaccion,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    conjuntoss4:conjuntos[];
    
}
