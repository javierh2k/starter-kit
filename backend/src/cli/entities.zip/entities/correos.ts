import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_correos_has_many_usuarios} from "./many_correos_has_many_usuarios";


@Entity("correos",{schema:"public"})
export class correos {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("integer",{ 
        nullable:false,
        name:"usuarios_id"
        })
    usuarios_id:number;
        

    @Column("integer",{ 
        nullable:false,
        name:"contacto_id"
        })
    contacto_id:number;
        

   
    @OneToOne(type=>many_correos_has_many_usuarios, many_correos_has_many_usuarios=>many_correos_has_many_usuarios.id_correos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_correos_has_many_usuarios:many_correos_has_many_usuarios | null;


   
    @OneToOne(type=>many_correos_has_many_usuarios, many_correos_has_many_usuarios=>many_correos_has_many_usuarios.id_correos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_correos_has_many_usuarios2:many_correos_has_many_usuarios | null;


   
    @OneToOne(type=>many_correos_has_many_usuarios, many_correos_has_many_usuarios=>many_correos_has_many_usuarios.id_correos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_correos_has_many_usuarios3:many_correos_has_many_usuarios | null;


   
    @OneToOne(type=>many_correos_has_many_usuarios, many_correos_has_many_usuarios=>many_correos_has_many_usuarios.id_correos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_correos_has_many_usuarios4:many_correos_has_many_usuarios | null;

}
