import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {usuarios} from "./usuarios";
import {many_transacciones_has_many_tipo_transaccion} from "./many_transacciones_has_many_tipo_transaccion";


@Entity("transacciones",{schema:"public"})
export class transacciones {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"egresoscol"
        })
    egresoscol:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"tipo_transaccion_id"
        })
    tipo_transaccion_id:number;
        

   
    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness2,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness3,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness4,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness5,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness6,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness7,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness8,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccioness9,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones2,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones3,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones4,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones5,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones6,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones7,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones8,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transacciones9,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione10,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione11,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione12,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione13,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione14,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione15,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione16,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione17,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione18,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione19,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione20,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione21,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione22,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione23,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione24,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione25,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione26,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;

    @ManyToOne(type=>usuarios, usuarios=>usuarios.transaccione27,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_usuarios'})
    id_usuarios:usuarios | null;


   
    @OneToOne(type=>many_transacciones_has_many_tipo_transaccion, many_transacciones_has_many_tipo_transaccion=>many_transacciones_has_many_tipo_transaccion.id_transacciones,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_transacciones_has_many_tipo_transaccion:many_transacciones_has_many_tipo_transaccion | null;

}
