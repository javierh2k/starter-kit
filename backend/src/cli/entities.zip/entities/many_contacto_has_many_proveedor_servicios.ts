import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {contacto} from "./contacto";


@Entity("many_contacto_has_many_proveedor_servicios",{schema:"public"})
export class many_contacto_has_many_proveedor_servicios {

   
    @OneToOne(type=>contacto, contacto=>contacto.many_contacto_has_many_proveedor_servicios,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_contacto'})
    id_contacto:contacto | null;

    @OneToOne(type=>contacto, contacto=>contacto.many_contacto_has_many_proveedor_servicios2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_contacto'})
    id_contacto:contacto | null;

    @OneToOne(type=>contacto, contacto=>contacto.many_contacto_has_many_proveedor_servicios3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_contacto'})
    id_contacto:contacto | null;

    @OneToOne(type=>contacto, contacto=>contacto.many_contacto_has_many_proveedor_servicios4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_contacto'})
    id_contacto:contacto | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_proveedor_servicios"
        })
    id_proveedor_servicios:number;
        
}
