import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {detalle_recurso} from "./detalle_recurso";
import {transacciones} from "./transacciones";


@Entity("usuarios",{schema:"public"})
export class usuarios {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"apellido"
        })
    apellido:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"rol"
        })
    rol:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"parqueadero"
        })
    parqueadero:string | null;
        

    @Column("integer",{ 
        nullable:true,
        name:"publicidad_correo"
        })
    publicidad_correo:number | null;
        

   
    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss2,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss3,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss4,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss5,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss6,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss7,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss8,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;

    @ManyToOne(type=>detalle_recurso, detalle_recurso=>detalle_recurso.usuarioss9,{ onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_detalle_recurso'})
    id_detalle_recurso:detalle_recurso | null;


   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness2:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness3:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness4:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness5:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness6:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness7:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness8:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccioness9:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones2:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones3:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones4:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones5:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones6:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones7:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones8:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transacciones9:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione10:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione11:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione12:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione13:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione14:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione15:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione16:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione17:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione18:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione19:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione20:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione21:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione22:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione23:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione24:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione25:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione26:transacciones[];
    

   
    @OneToMany(type=>transacciones, transacciones=>transacciones.id_usuarios,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    transaccione27:transacciones[];
    
}
