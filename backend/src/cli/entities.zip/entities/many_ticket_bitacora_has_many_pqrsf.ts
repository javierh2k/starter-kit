import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {ticket_bitacora} from "./ticket_bitacora";


@Entity("many_ticket_bitacora_has_many_pqrsf",{schema:"public"})
export class many_ticket_bitacora_has_many_pqrsf {

   
    @OneToOne(type=>ticket_bitacora, ticket_bitacora=>ticket_bitacora.many_ticket_bitacora_has_many_pqrsf,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_ticket_bitacora'})
    id_ticket_bitacora:ticket_bitacora | null;

    @OneToOne(type=>ticket_bitacora, ticket_bitacora=>ticket_bitacora.many_ticket_bitacora_has_many_pqrsf2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_ticket_bitacora'})
    id_ticket_bitacora:ticket_bitacora | null;

    @OneToOne(type=>ticket_bitacora, ticket_bitacora=>ticket_bitacora.many_ticket_bitacora_has_many_pqrsf3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_ticket_bitacora'})
    id_ticket_bitacora:ticket_bitacora | null;

    @OneToOne(type=>ticket_bitacora, ticket_bitacora=>ticket_bitacora.many_ticket_bitacora_has_many_pqrsf4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_ticket_bitacora'})
    id_ticket_bitacora:ticket_bitacora | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_pqrsf"
        })
    id_pqrsf:number;
        
}
