import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {conjuntos} from "./conjuntos";
import {zona} from "./zona";


@Entity("many_conjuntos_has_many_zona",{schema:"public"})
export class many_conjuntos_has_many_zona {

   
    @OneToOne(type=>conjuntos, conjuntos=>conjuntos.many_conjuntos_has_many_zona,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_conjuntos'})
    id_conjuntos:conjuntos | null;

    @OneToOne(type=>conjuntos, conjuntos=>conjuntos.many_conjuntos_has_many_zona2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_conjuntos'})
    id_conjuntos:conjuntos | null;

    @OneToOne(type=>conjuntos, conjuntos=>conjuntos.many_conjuntos_has_many_zona3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_conjuntos'})
    id_conjuntos:conjuntos | null;

    @OneToOne(type=>conjuntos, conjuntos=>conjuntos.many_conjuntos_has_many_zona4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_conjuntos'})
    id_conjuntos:conjuntos | null;


   
    @OneToOne(type=>zona, zona=>zona.many_conjuntos_has_many_zona,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_zona'})
    id_zona:zona | null;

    @OneToOne(type=>zona, zona=>zona.many_conjuntos_has_many_zona2,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_zona'})
    id_zona:zona | null;

    @OneToOne(type=>zona, zona=>zona.many_conjuntos_has_many_zona3,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_zona'})
    id_zona:zona | null;

    @OneToOne(type=>zona, zona=>zona.many_conjuntos_has_many_zona4,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_zona'})
    id_zona:zona | null;

}
