import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {ticket_documentos} from "./ticket_documentos";


@Entity("many_ticket_documentos_has_many_ticket_bitacora",{schema:"public"})
export class many_ticket_documentos_has_many_ticket_bitacora {

   
    @OneToOne(type=>ticket_documentos, ticket_documentos=>ticket_documentos.many_ticket_documentos_has_many_ticket_bitacora,{ primary:true, nullable:false,onDelete: 'RESTRICT',onUpdate: 'CASCADE' })
    @JoinColumn({ name:'id_ticket_documentos'})
    id_ticket_documentos:ticket_documentos | null;


    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id_ticket_bitacora"
        })
    id_ticket_bitacora:number;
        
}
