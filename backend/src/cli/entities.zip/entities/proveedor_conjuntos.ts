import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_recursoyservicios_has_many_proveedor_conjuntos} from "./many_recursoyservicios_has_many_proveedor_conjuntos";


@Entity("proveedor_conjuntos",{schema:"public"})
export class proveedor_conjuntos {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;
        

   
    @OneToOne(type=>many_recursoyservicios_has_many_proveedor_conjuntos, many_recursoyservicios_has_many_proveedor_conjuntos=>many_recursoyservicios_has_many_proveedor_conjuntos.id_proveedor_conjuntos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_recursoyservicios_has_many_proveedor_conjuntos:many_recursoyservicios_has_many_proveedor_conjuntos | null;

}
