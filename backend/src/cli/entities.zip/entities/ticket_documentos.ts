import {Index,Entity, PrimaryColumn, PrimaryGeneratedColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable, RelationId} from "typeorm";
import {many_ticket_documentos_has_many_ticket_bitacora} from "./many_ticket_documentos_has_many_ticket_bitacora";


@Entity("ticket_documentos",{schema:"public"})
export class ticket_documentos {

    @Column("integer",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("character varying",{ 
        nullable:true,
        length:45,
        name:"titulo"
        })
    titulo:string | null;
        

    @Column("integer",{ 
        nullable:false,
        name:"ticket_bitacora_id"
        })
    ticket_bitacora_id:number;
        

   
    @OneToOne(type=>many_ticket_documentos_has_many_ticket_bitacora, many_ticket_documentos_has_many_ticket_bitacora=>many_ticket_documentos_has_many_ticket_bitacora.id_ticket_documentos,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    many_ticket_documentos_has_many_ticket_bitacora:many_ticket_documentos_has_many_ticket_bitacora | null;

}
