import {
    Column, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne,
    PrimaryColumn, PrimaryGeneratedColumn, RelationId
} from 'typeorm';

import { ManyInmuebleHasManyCategoria } from './ManyInmuebleHasManyCategoria';

@Entity("categoria",{schema:"public"})
export class categoria {

    @Column("integer",{
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;


    @Column("character varying",{
        nullable:true,
        length:45,
        name:"nombre"
        })
    nombre:string | null;



    @OneToOne(type=>ManyInmuebleHasManyCategoria, ManyInmuebleHasManyCategoria=>ManyInmuebleHasManyCategoria.id_categoria,{ onDelete: 'RESTRICT' ,onUpdate: 'CASCADE' })
    ManyInmuebleHasManyCategoria:ManyInmuebleHasManyCategoria | null;

}
